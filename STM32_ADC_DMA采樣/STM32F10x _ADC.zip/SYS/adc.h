#ifndef __ADC_H_
#define __ADC_H_


#include "stm32f10x.h"
#include "sys.h"
#include "delay.h"


extern float voltage1;    
extern float voltage2;

extern float voltage3;
extern float voltage4;

extern float voltage5;
extern float voltage6;
 
 
void adc_init(void); 
u16 Get_ADC_Value(u8 ch,u8 times); //�ɼ�adcֵ
void voltage_get(void);           
void DMA_Configuration(void);

#endif



