#ifndef __USART_H
#define	__USART_H
#include <stdio.h>
#include "stdint.h"
void USART1_Config(uint32_t baud);
//int fputc(int ch, FILE *f);
//void USART1_printf(USART_TypeDef* USARTx, uint8_t *Data,...);

#endif /* __USART1_H */
