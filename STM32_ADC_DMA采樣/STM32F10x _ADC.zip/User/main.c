#include "stm32f10x.h"
#include "usart.h"
#include "delay.h"
#include "adc.h"


int main(void)
{
		adc_init( );
    USART1_Config(9600);
	  printf("\r\nADC늉��ɼ������@ʾ\r\n");

	while(1)
	{
		voltage_get( );
	  printf("voltage1:%f\r\n",voltage1);
		printf("voltage2:%f\r\n",voltage2);
		printf("voltage3:%f\r\n",voltage3);
		printf("voltage4:%f\r\n",voltage4);
		printf("voltage5:%f\r\n",voltage5);
		printf("voltage6:%f\r\n",voltage6);
		delay_ms(1000);
	}

}
