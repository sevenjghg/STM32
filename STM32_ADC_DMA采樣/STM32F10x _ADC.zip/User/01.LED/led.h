#ifndef  __LED_H_
#define  __LED_H_
#include "stm32f10x.h"

#define LED_Pin GPIO_Pin_13
#define LED_Port GPIOC
#define RCC_APB2Periph_LED_Port RCC_APB2Periph_GPIOC







void LED_GPIO_Config(void);
void LED_GPIO_High(void);
void LED_GPIO_Low(void);








#endif
