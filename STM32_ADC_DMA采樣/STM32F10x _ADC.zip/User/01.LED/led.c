/*******************************************************
********************************************************
******************LED������*****************************
*******************����PC13*****************************
********************************************************
*******************************************************/


#include "stm32f10x.h"
#include "led.h"


void LED_GPIO_Config(void)
{
	GPIO_InitTypeDef GPIO_Struct;
	//ʱ������
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_LED_Port, ENABLE);
	//��������	
	GPIO_Struct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Struct.GPIO_Pin = LED_Pin;
	GPIO_Struct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(LED_Port ,&GPIO_Struct);
}

void LED_GPIO_High(void)
{
	GPIO_SetBits(LED_Port, LED_Pin);

}

void LED_GPIO_Low(void)
{
	GPIO_ResetBits(LED_Port, LED_Pin);

}
