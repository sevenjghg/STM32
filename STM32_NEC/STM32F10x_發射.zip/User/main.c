#include "stm32f10x.h"
//#include "timer3.h"
//#include "led.h"
//#include "usart2.h"
//#include "oled.h"
//#include "adc.h"
#include "nec.h"
#include "delay.h"




int main(void)
{
	delay_init();
	NEC_TX_Configuration( );
//	TIM_SetCompare1(TIM3,9);
//	NVIC_InitTypeDef NVIC_InitStruct;	
// 	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  //�жϷ���  2���������ȼ���������Ӧ���ȼ�
//	OLED_Init();
//	OLED_ColorTurn(0);//0????,1 ????
//  OLED_DisplayTurn(0);//0???? 1 ??????
//	TIM3_Init(1000-1,7200-1);	 //????PWM??=72000000/900=80Khz
//	NVIC_InitStruct.NVIC_IRQChannel = TIM3_IRQn;    //�ж�ԴΪ��ʱ��3
//	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;  //�������ȼ�
//	NVIC_InitStruct.NVIC_IRQChannelSubPriority  = 2;  //��Ӧ���ȼ�
////	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;       //�ж�ʹ��
//	NVIC_Init(&NVIC_InitStruct);
////	u16 temp;
//	 LED_GPIO_Config();
//// 
//	USART2_Init();
//	adc_init();
////  USART_SendByte(USART2, '1');
//	USART_SendString(USART2, "��ͳ");
////	USART_SendData( USART2, 'D');
	NEC_Send(0xFF,0xFF,0);
	
	
	while(1)
	{
//		delay(500);
//		OLED_Clear();
//		OLED_ShowChinese(0,0,0,16,1);//?
//		OLED_ShowChinese(18,0,1,16,1);//?
//		OLED_ShowChinese(36,0,2,16,1);//?
//		OLED_ShowChinese(54,0,3,16,1);//?
//		OLED_ShowChinese(72,0,4,16,1);//?
//		OLED_ShowChinese(90,0,5,16,1);//?
//		OLED_ShowChinese(108,0,6,16,1);//?
//		OLED_Refresh(); 
//	temp = USART_ReciveByte(USART2);
//	 USART_SendByte(USART2, 'D');
//		LED_GPIO_Low();
//		delay(1000);
//		LED_GPIO_High();
//		delay(1000);
//	
//    ADC_GetConversionValue(ADC1);

	}

}
