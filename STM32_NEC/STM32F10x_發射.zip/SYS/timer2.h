#ifndef __TIMER2_H__
#define __TIMER2_H__

#include "stm32f10X.h"


void TIM2_Init(u16 arr,u16 psc);

void TIM2_IRQHandler(void);

#endif

