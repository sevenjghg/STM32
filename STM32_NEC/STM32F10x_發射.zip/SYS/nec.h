#ifndef __NEC_H_
#define __NEC_H_


#include "stm32f10x.h"

#include "delay.h"

void NEC_Send(u8 addr,u8 value,u8 cnt);
void NEC_TX_Configuration(void);

#endif
