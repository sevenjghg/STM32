#ifndef __PWM2_H
#define __PWM2_H
#include "stm32f10x.h"


void TIM2_PWM_Init(u16 arr,u16 psc);

#endif


