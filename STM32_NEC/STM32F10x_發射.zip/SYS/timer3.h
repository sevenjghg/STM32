#ifndef __TIMER3_H__
#define __TIMER3_H__

#include "stm32f10X.h"


void TIM3_Init(u16 arr,u16 psc);



#endif

