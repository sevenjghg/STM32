#ifndef __PWM3_H
#define __PWM3_H
#include "stm32f10x.h"


void TIM3_PWM_Init(u16 arr,u16 psc);

#endif


