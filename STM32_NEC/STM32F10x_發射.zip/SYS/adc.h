#ifndef __ADC_H_
#define __ADC_H_


#include "stm32f10x.h"


void adc_init(void);

#endif
