#include "stm32f10x.h"
//#include "timer3.h"
//#include "led.h"
//#include "usart2.h"
//#include "oled.h"
//#include "adc.h"
#include "nec.h"
#include "delay.h"
#include "key.h"



 
 void gpio_config(void)
 {
		 GPIO_InitTypeDef GPIO_InitStructure;
		 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);	
	 
	 	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
		 GPIO_Init(GPIOC, &GPIO_InitStructure);
 
 }

 

int main(void)
{
	u8  i;
	delay_init();
  gpio_config( );
	KEY_Init( );
	NEC_TX_Configuration( );
//	NEC_Send(0xFF,0xFF,0);
	GPIO_SetBits(GPIOC,GPIO_Pin_13);

	while(1)
	{
		i =  KEY_Scan(1);
		switch(i){
			case 1:				GPIO_ResetBits(GPIOC,GPIO_Pin_13);
              			NEC_Send(0xFF,0xFF,0);
			break;
			case 2:				GPIO_SetBits(GPIOC,GPIO_Pin_13);
            				NEC_Send(0xFF,0x00,0);
			break;
			}
//		if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_3)== RESET)
//		{
//			delay_ms(10);
//			if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_3)== RESET)
//			{
//				GPIO_ResetBits(GPIOC,GPIO_Pin_13);
//				NEC_Send(0xFF,0xFF,0);
//			}
//			
//		  if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4)== RESET)
//		  {
//			delay_ms(10);
//			if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4)== RESET)
//			 {
//				GPIO_SetBits(GPIOC,GPIO_Pin_13);
//				NEC_Send(0xFF,0x00,0);
//			 }
//		  }
//	  }

  }
}