
#include "nec.h"
/****************************************************************************************/
#define CARRIER_38KHz() TIM_SetCompare1(TIM3,9)
#define NO_CARRIER()    TIM_SetCompare1(TIM3,0)


void NEC_TX_Configuration(void)            
{
      //??????//
	GPIO_InitTypeDef GPIO_InitStructure;            
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseInitStruct; 
	TIM_OCInitTypeDef  TIM_OCInitStructure;         
	
	//**????**//
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	 
	
	//**GPIOB_Pin6???**//
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;				 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; 		 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		
	GPIO_Init(GPIOA, &GPIO_InitStructure);					 
	GPIO_ResetBits(GPIOA,GPIO_Pin_6);


  //TIM4???
	TIM_TimeBaseInitStruct.TIM_Period = 25; 
	TIM_TimeBaseInitStruct.TIM_Prescaler =71; 
	TIM_TimeBaseInitStruct.TIM_ClockDivision = 0; 
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;  
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStruct); 

	//???TIM4 channel1 PWM	?? 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; 
	TIM_OC1Init(TIM3, &TIM_OCInitStructure);  

	TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable); 
  
	TIM_Cmd(TIM3, ENABLE);  
}

static void NEC_Send_Head(void){
        CARRIER_38KHz();        
        delay_us(9000);
        NO_CARRIER();        
        delay_us(4500);
}

static void NEC_Send_BYTE(u8 value)
{
        u8 i;
        
        for(i=0;i<8;i++)
        {
                if( value & 0x80 ){
                        CARRIER_38KHz();      
                        delay_us(560);
                        NO_CARRIER();      
                        delay_us(1680);
                }
                else{
                        CARRIER_38KHz();       
                        delay_us(560);
                        NO_CARRIER();        
                        delay_us(560);
                }
                value<<=1;
        }
}

static void NEC_Send_Repeat(u8 repeatcnt)
{
    u8 i;
        
    if(repeatcnt==0)          
    {
        CARRIER_38KHz();
        delay_us(560);
        NO_CARRIER();     
    }
        else 
    {
        for(i=0;i<repeatcnt;++i)
        {
            CARRIER_38KHz();
            delay_us(560);
            NO_CARRIER();
            delay_ms(98);
            CARRIER_38KHz();
            delay_us(9000);  
            NO_CARRIER();
            delay_us(2250);                     
        }

                CARRIER_38KHz();
                delay_us(560);
                NO_CARRIER(); 
    }
}


void NEC_Send(u8 addr,u8 value,u8 cnt){

       // NEC_TX_Configuration();
        
        NEC_Send_Head();                                
        NEC_Send_BYTE(addr);                       
        NEC_Send_BYTE(~addr);                       
        NEC_Send_BYTE(value);                       
        NEC_Send_BYTE(~value);                       
        NEC_Send_Repeat(cnt);                              

       // NEC_RX_Configuration();
}

