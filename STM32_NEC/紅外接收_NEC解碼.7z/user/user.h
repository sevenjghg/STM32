#ifndef __USER_H
#define __USER_H

void Capture_Config(void);

#endif
