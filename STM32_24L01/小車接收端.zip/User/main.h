#ifndef __MAIN_H_
#define __MAIN_H_

void NRF24L01_Date_Update(void);

#endif

