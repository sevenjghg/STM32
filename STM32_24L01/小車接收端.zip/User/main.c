#include "system.h"
#include "SysTick.h"
#include "led.h"
#include "spi.h"
#include "24l01.h"  
#include "usart1.h"
#include "timer.h"
#include "pwm.h"
#include "main.h"
#include "irm.h"

#define send_buf_len 5000
u8 send_buf[send_buf_len];
float rx_left_x,rx_left_y;
u8 key1,key2;
float rx_right_x,rx_right_y;
u8 key3,key4;
u8 t;
u8 tmp_buf[33]; 
u8 car_mode;
u16 state=0;

void delay(u32 i)
{
	 while(i--);
}

void NRF24L01_Date_Update(void)
{
		if(NRF24L01_RxPacket(tmp_buf)==0)//һ�����յ���Ϣ,����ʾ����.
		{
			tmp_buf[32]=0;//�����ַ���������
			for(t=0;t<32;t++)
			{
				if(tmp_buf[t]=='l'&&tmp_buf[t+1]=='x'&&tmp_buf[t+2]==':')
				{
					rx_left_x=(float)(tmp_buf[t+3]-0x30)+(float)(tmp_buf[t+4]-0x30)/10+(float)(tmp_buf[t+5]-0x30)/100+(float)(tmp_buf[t+6]-0x30)/1000;
					rx_left_y=(float)(tmp_buf[t+7]-0x30)+(float)(tmp_buf[t+8]-0x30)/10+(float)(tmp_buf[t+9]-0x30)/100+(float)(tmp_buf[t+10]-0x30)/1000;
					key1=tmp_buf[t+12]-0x30;
					key2=tmp_buf[t+15]-0x30;
					printf("---------------NRF24L01_Update---------------\r\n");
					printf("left_x:%f,left_y:%f,key1:%d,key2:%d\r\n",rx_left_x,rx_left_y,key1,key2);
				}
				if(tmp_buf[t]=='r'&&tmp_buf[t+1]=='x'&&tmp_buf[t+2]==':')
				{
					rx_right_x=(float)(tmp_buf[t+3]-0x30)+(float)(tmp_buf[t+4]-0x30)/10+(float)(tmp_buf[t+5]-0x30)/100+(float)(tmp_buf[t+6]-0x30)/1000;
					rx_right_y=(float)(tmp_buf[t+7]-0x30)+(float)(tmp_buf[t+8]-0x30)/10+(float)(tmp_buf[t+9]-0x30)/100+(float)(tmp_buf[t+10]-0x30)/1000;
					key3=tmp_buf[t+12]-0x30;
					key4=tmp_buf[t+15]-0x30;
					printf("right_x:%f,right_y:%f,key3:%d,key4:%d\r\n",rx_right_x,rx_right_y,key3,key4);
				}							
			}						
		}
}

void state_get(void)
{
	if(GPIO_ReadInputDataBit(IRM_Port,IRM_FORWARD)==1 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_FORWARD)==0 
		 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_RIGHT)==0 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_LEFT)==0 ) //�]���ϵK��
	{
		state = 0;
	}
	if(GPIO_ReadInputDataBit(IRM_Port,IRM_FORWARD)==0 ) //ǰ�������ϵK��
	{
		state = 1;
	}
	if(GPIO_ReadInputDataBit(IRM_Port,IRM_FORWARD)==1 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_FORWARD)==1 
		 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_RIGHT)==0 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_LEFT)==0 ) //ǰ������
	{
		state = 2;
	}
	if(GPIO_ReadInputDataBit(IRM_Port,IRM_FORWARD)==1 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_FORWARD)==0 
		 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_RIGHT)==1 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_LEFT)==0 ) //��߅����
	{
		state = 3;
	}
	if(GPIO_ReadInputDataBit(IRM_Port,IRM_FORWARD)==1 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_FORWARD)==0 
		 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_RIGHT)==0 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_LEFT)==1 ) //��߅����
	{
		state = 4;
	}
	if(GPIO_ReadInputDataBit(IRM_Port,IRM_FORWARD)==1 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_FORWARD)==1
		 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_RIGHT)==1 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_LEFT)==0 ) //ǰ߅��߅����
	{
		state = 5;
	}
	if(GPIO_ReadInputDataBit(IRM_Port,IRM_FORWARD)==1 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_FORWARD)==1 
		 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_RIGHT)==0 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_LEFT)==1 ) //ǰ߅��߅����
	{
		state = 6;
	}
	if( GPIO_ReadInputDataBit(IRM_Port,CLIFF_FORWARD)==1 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_RIGHT)==1 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_LEFT)==1 ) //�]���ϵK��
	{
		state = 7;
	}
}

int main()
{

	SysTick_Init(72);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	
	gpio_init();
	irm_config();
	USART1_Init();
//	timer_1ms();
	led_Init();
	pwm_config();
	NRF24L01_Init();    	                       	  //��ʼ��NRF24L01 
	printf("---------------system power on-----------------\r\n");
//	LED_RGB_RED();	
	delay_ms(1000);
	while(NRF24L01_Check())                         //LED���W�q�ȴ��B��NRF24L01
	{
		GPIO_SetBits(LED_PORT,LED_PIN);
		delay_ms(1000);
		GPIO_ResetBits(LED_PORT,LED_PIN);
		delay_ms(1000);  
		printf("waiting connect nrf24l01......\r\n");
	}
	delay_ms(1000);
	LED_RGB_RED();											 						//ϵ�y��� �@ʾ�t��            
	printf("------------nrf24l01 connect sucess------------\r\n");
	NRF24L01_RX_Mode();                            //NRF24L01�O�à�RX����ģʽ
	printf("---------------nrf24l01 RX mode----------------\r\n");
	turn_stop();
	while(1)
	{
		NRF24L01_Date_Update();	
//		if(	system_timer_1ms_flag == 1)              //5ms���r��־λ
//		{
			if(key1==0&&key2==1)											 //���I1����
			{
				car_mode=1;															 //�b��ģʽ  
				LED_RGB_BLUE();
			}
			if(key1==1&&key2==0)											 //���I2����
			{
				car_mode=2;															 //�Ԅ�ģʽ 
				LED_RGB_GREEN();
			}
//			if(key3==0)																 //���I3����
//			{
//			}
//			if(key4==0)                                //���I4����
//			{

//			}
//			system_timer_5ms_flag = 0;
//		}
	 	if(car_mode == 1)															//�u�Uģʽ
		{
			if(rx_left_y > 3.1 && 1 < rx_right_x && rx_right_x < 2)   //ǰ�M
			{
				turn_forward();
			}
			if(rx_left_y < 1 && 1 < rx_right_x && rx_right_x < 2)  //����
			{
				turn_back();
			}
			if(1 < rx_left_y && rx_left_y < 2 && 1 < rx_right_x && rx_right_x < 2)                     //ֹͣ
			{
				turn_stop();
			}
			if(rx_left_y > 3 && rx_right_x < 1 )      //ǰ�M���D
			{
				turn_left();
			}	
			if(rx_left_y > 3 && rx_right_x > 3 )        //ǰ�M���D
			{
				turn_right();
			}	
			if(rx_left_y < 1 && rx_right_x < 1)
			{
				turn_right();
			}
			if(rx_left_y < 1 && rx_right_x > 3 )        //ǰ�M���D
			{
				turn_left();
			}	
			if(1 < rx_left_y && rx_left_y < 2 &&  rx_right_x < 1)
			{
				turn_left();
			}
			if(1 < rx_left_y && rx_left_y < 2 &&  rx_right_x > 3)
			{
				turn_right();
			}
		}		
		if(car_mode == 2)															//�Ԅ�ģʽģʽ
		{
			state_get();                //�@ȡIRM����Ϣ
			switch(state)
			{
				case 0:                 //�o�ϵK��  ����ǰ�M
					turn_forward();
				break;
				case 1:                 //ǰ�����ϵK��
					
					if(GPIO_ReadInputDataBit(IRM_Port,CLIFF_FORWARD)==0 
						&& GPIO_ReadInputDataBit(IRM_Port,CLIFF_RIGHT)==0 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_LEFT)==0 ) //�]�Б���
					{
						turn_back();
						delay_ms(500);
						turn_right();
						delay_ms(400);
					}
					if(GPIO_ReadInputDataBit(IRM_Port,CLIFF_FORWARD)==1 
						&& GPIO_ReadInputDataBit(IRM_Port,CLIFF_RIGHT)==0 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_LEFT)==0 ) //ǰ������
					{
						turn_back();
						delay_ms(500);
						turn_right();
						delay_ms(400);
					}
					if(GPIO_ReadInputDataBit(IRM_Port,CLIFF_FORWARD)==0 
						&& GPIO_ReadInputDataBit(IRM_Port,CLIFF_RIGHT)==1 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_LEFT)==0 ) //��߅����
					{
						turn_back();
						delay_ms(500);
						turn_left();
						delay_ms(400);
					}
					if(GPIO_ReadInputDataBit(IRM_Port,CLIFF_FORWARD)==0 
						&& GPIO_ReadInputDataBit(IRM_Port,CLIFF_RIGHT)==0 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_LEFT)==1 ) //��߅����
					{
						turn_back();
						delay_ms(500);
						turn_right();
						delay_ms(400);
					}
					if(GPIO_ReadInputDataBit(IRM_Port,CLIFF_FORWARD)==1
						&& GPIO_ReadInputDataBit(IRM_Port,CLIFF_RIGHT)==1 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_LEFT)==0 ) //ǰ߅��߅����
					{
						turn_back();
						delay_ms(500);
						turn_left();
						delay_ms(400);
					}
					if(GPIO_ReadInputDataBit(IRM_Port,CLIFF_FORWARD)==1 
						&& GPIO_ReadInputDataBit(IRM_Port,CLIFF_RIGHT)==0 && GPIO_ReadInputDataBit(IRM_Port,CLIFF_LEFT)==1 ) //ǰ߅��߅����
					{
						turn_back();
						delay_ms(500);
						turn_right();
						delay_ms(400);
					}
				break;
				case 2:                 //ǰ������
						turn_back();
						delay_ms(500);
						turn_right();
						delay_ms(400);
				break;
				case 3:                 //��߅����
						turn_back();
						delay_ms(500);
						turn_left();
						delay_ms(400);
				break;
				case 4:                 //��߅����
						turn_back();
						delay_ms(500);
						turn_right();
						delay_ms(400);
				break;
				case 5:                 //ǰ߅��߅����
						turn_back();
						delay_ms(500);
						turn_left();
						delay_ms(400);
				break;
				case 6:                 //ǰ߅��߅����
						turn_back();
						delay_ms(500);
						turn_right();
						delay_ms(400);
				break;
				case 7:                 //ǰ߅��߅����
						turn_stop();
				break;
				
			}
		
		}	
  }	       
}
	  
			
		
