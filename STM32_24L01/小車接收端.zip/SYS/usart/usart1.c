
#include "usart1.h"  //������Ҫ��ͷ�ļ�




void USART1_Init(void)
{
	//����ṹ��
	GPIO_InitTypeDef GPIO_InitStruct;
	USART_InitTypeDef USART_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;
		
	//RCCʱ��ʹ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 , ENABLE);
	
	//GPIOA_PIN_2��ʼ������	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;   
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9;        //
	GPIO_InitStruct.GPIO_Speed = 	GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	//GPIOA_PIN_3��ʼ������	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;   // 
	//	GPIO_InitStruct.GPIO_Speed = 	GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	//USART��ʼ������
	USART_InitStruct.USART_Mode = USART_Mode_Tx|USART_Mode_Rx  ;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None ;
	USART_InitStruct.USART_Parity = USART_Parity_No;
	USART_InitStruct.USART_BaudRate = 9600;
	USART_InitStruct.USART_StopBits = 	USART_StopBits_1 ;
	USART_Init( USART1, &USART_InitStruct);
	
	//NVIC�ж�����
	NVIC_InitStruct.NVIC_IRQChannel =   USART1_IRQn  ;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStruct);
	
	

	USART_ITConfig( USART1, USART_IT_RXNE, ENABLE);
	USART_Cmd(USART1, ENABLE);
	
	
}

void USART_SendByte(USART_TypeDef* USARTx, uint16_t Data)
{
  /* Check the parameters */
  assert_param(IS_USART_ALL_PERIPH(USARTx));
  assert_param(IS_USART_DATA(Data)); 
    
  /* Transmit Data */
  USARTx->DR = (Data & (uint16_t)0x01FF);
  while (USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET);

}

void USART_SendString( USART_TypeDef * USARTx, char *str)
{
     while(*str!='\0')
     {
         USART_SendByte( USARTx, *str++ );	
     }
     while(USART_GetFlagStatus(USARTx,USART_FLAG_TC)==RESET);
}

uint8_t USART_ReceiveByte(USART_TypeDef* USARTx)
{
  while(USART_GetFlagStatus(USARTx,USART_FLAG_RXNE)==RESET);
  
  return (uint8_t)USART_ReceiveData(USART1);

}

void USART_SendFloat(USART_TypeDef* USARTx,float d)
{
	char str[6] = {0};
	unsigned int temp = (unsigned int)(d * 100);

	str[0] = temp /1000 + 48;		/*???48????:???????????
									????,????????2????ASCII??
									?????48*/
	str[1] = temp /100%10 + 48;	
	str[2] = '.';
	str[3] = temp /10%10 + 48;
	str[4] = temp % 10 + 48;
	str[5] = '\0';
	
	USART_SendString(  USARTx,str);
}

//�жϺ���
void USART1_IRQHandler()
{
	//printf("enter the usart irq\r\n");
//	while(USART_GetITStatus(USART1,USART_IT_RXNE) == RESET);
	if(USART_GetITStatus(USART1,USART_IT_RXNE) != RESET)
	{
		//printf("enter the usart irq\r\n");
		USART_ClearITPendingBit(USART1,USART_IT_RXNE); //����жϱ�־

	
	}
		//USART_SendByte(USART1,t);

}
#pragma import(__use_no_semihosting)             
                 
struct __FILE 
{ 
	int handle; 

}; 

FILE __stdout;          
void _sys_exit(int x) 
{ 
	x = x; 
} 

int fputc(int ch, FILE *f)
{
		
		USART_SendData(USART1, (uint8_t) ch);			
		while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);			
		return (ch);
}


int fgetc(FILE *f)
{		
		while (USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == RESET);
		return (int)USART_ReceiveData(USART1);
}

