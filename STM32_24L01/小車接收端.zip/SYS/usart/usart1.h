#ifndef __USART1_H
#define __USART1_H
#include "system.h"
#include "stdio.h"
//#include "stdio.h"
extern int usart1_flag;
void USART1_Init(void);
void USART_SendByte(USART_TypeDef* USARTx, uint16_t Data);
void USART_SendString(USART_TypeDef * USARTx, char *str);
uint8_t USART_ReceiveByte(USART_TypeDef* USARTx);
void USART_SendFloat(USART_TypeDef* USARTx,float d);

#endif
