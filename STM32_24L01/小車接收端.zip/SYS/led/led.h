#ifndef _led_H
#define _led_H
#include "system.h"


#define LED_PORT_RCC    RCC_APB2Periph_GPIOC
#define LED_PIN				  GPIO_Pin_13
#define LED_PORT				GPIOC

#define LED_RED				  GPIO_Pin_9
#define LED_GREEN			  GPIO_Pin_8
#define LED_BLUE			  GPIO_Pin_6
#define LED_RGB					GPIOB


void led_Init(void);
void LED_RGB_RED(void);
void LED_RGB_GREEN(void);
void LED_RGB_BLUE(void);

#endif
