#include "led.h"

void led_Init()
{     //
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd( LED_PORT_RCC, ENABLE);
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitStruct.GPIO_Pin=LED_PIN; //
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;	//
	GPIO_Init(LED_PORT,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Pin=LED_RED	|LED_GREEN	|LED_BLUE	; //
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;	
	GPIO_Init(LED_RGB ,&GPIO_InitStruct);

//	GPIO_SetBits(LED_PORT,LED_PIN);

}


void LED_RGB_RED(void)
{
	GPIO_SetBits(LED_RGB,LED_RED);
	GPIO_ResetBits(LED_RGB,LED_GREEN);
	GPIO_ResetBits(LED_RGB,LED_BLUE);
}

void LED_RGB_GREEN(void)
{
	GPIO_ResetBits(LED_RGB,LED_RED);
	GPIO_SetBits(LED_RGB,LED_GREEN);
	GPIO_ResetBits(LED_RGB,LED_BLUE);
}

void LED_RGB_BLUE(void)
{
	GPIO_ResetBits(LED_RGB,LED_RED);
	GPIO_ResetBits(LED_RGB,LED_GREEN);
	GPIO_SetBits(LED_RGB,LED_BLUE);
}
