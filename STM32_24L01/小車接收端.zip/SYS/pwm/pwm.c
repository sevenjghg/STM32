#include "pwm.h"


/*******************************************TB6612�ӳ�ʽ*************************************************
PA1  - PWMA  ��݆
AIN1 - PA4
AIN2 - PA3

PA2  - PWMB  ��݆
BIN1 - PA5
BIN2 - PA6

***********************************************************************************************************/

void pwm_config(void)            
{
	
	GPIO_InitTypeDef GPIO_InitStruct;            
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseInitStruct; 
	TIM_OCInitTypeDef  TIM_OCInitStructure;         
	
	//RCC�r�ʹ��//
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	 
	
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_1;				 
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP; 		 
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;		
	GPIO_Init(GPIOA, &GPIO_InitStruct);					 
	GPIO_ResetBits(GPIOA,GPIO_Pin_1);
	
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2;				 
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP; 		 
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;		
	GPIO_Init(GPIOA, &GPIO_InitStruct);					 
	GPIO_ResetBits(GPIOA,GPIO_Pin_2);	
		
	//TIM2
	TIM_TimeBaseInitStruct.TIM_Period = 50; 
	TIM_TimeBaseInitStruct.TIM_Prescaler =71; 
	TIM_TimeBaseInitStruct.TIM_ClockDivision = 0; 
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;  
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStruct); 
//	
	//TIM2 channel2 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; 
	TIM_OC2Init(TIM2, &TIM_OCInitStructure); 
	
	//TIM2 channel3 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; 
	TIM_OC3Init(TIM2, &TIM_OCInitStructure);
		
	TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable); 
  TIM_OC3PreloadConfig(TIM2, TIM_OCPreload_Enable); 

	TIM_SetCompare2(TIM2,15);  
	TIM_SetCompare3(TIM2,15);
				
	TIM_Cmd(TIM2, ENABLE);  
	

}

void gpio_init(void)
{
	GPIO_InitTypeDef  GPIO_InitStruct;

	//����ⲿ�жϵĻ���һ��ʹ��AFIO���ù���
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO ,ENABLE);
	//ֻ�ر�JTAG������SWD 
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
	//����IO�˿�
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;      
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;           
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;  
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	
}

//ǰ��
void turn_forward(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_4);
	GPIO_SetBits(GPIOA,GPIO_Pin_5);	
	GPIO_ResetBits(GPIOA,GPIO_Pin_3);
	GPIO_ResetBits(GPIOA,GPIO_Pin_6);
}

//����
void turn_back(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_3);
	GPIO_SetBits(GPIOA,GPIO_Pin_6);	
	GPIO_ResetBits(GPIOA,GPIO_Pin_4);
	GPIO_ResetBits(GPIOA,GPIO_Pin_5);
}
//ֹͣ
void turn_stop(void)
{
	GPIO_ResetBits(GPIOA,GPIO_Pin_4);
	GPIO_ResetBits(GPIOA,GPIO_Pin_5);	
	GPIO_ResetBits(GPIOA,GPIO_Pin_3);
	GPIO_ResetBits(GPIOA,GPIO_Pin_6);
}

void turn_right(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_3);
	GPIO_SetBits(GPIOA,GPIO_Pin_5);	
	GPIO_ResetBits(GPIOA,GPIO_Pin_4);
	GPIO_ResetBits(GPIOA,GPIO_Pin_6);
}
void turn_left(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_4);
	GPIO_SetBits(GPIOA,GPIO_Pin_6);	
	GPIO_ResetBits(GPIOA,GPIO_Pin_3);
	GPIO_ResetBits(GPIOA,GPIO_Pin_5);
}
void debug(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_3);
	GPIO_SetBits(GPIOA,GPIO_Pin_5);
	
	GPIO_SetBits(GPIOA,GPIO_Pin_4);
	GPIO_SetBits(GPIOA,GPIO_Pin_6);
	GPIO_SetBits(GPIOA,GPIO_Pin_7);

}
