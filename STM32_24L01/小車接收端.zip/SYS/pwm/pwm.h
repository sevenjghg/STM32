#ifndef __PWM_H_
#define __PWM_H_


#include "system.h"




void pwm_config(void);
void gpio_init(void);
void turn_forward(void);
void turn_back(void);
void turn_stop(void);
void turn_left(void);
void turn_right(void);
void debug(void);
void Circle_right(void);
void Circle_left(void);
#endif
