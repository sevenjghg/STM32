#ifndef __IRM_H_
#define __IRM_H_
#include "system.h"

#define CLIFF_RIGHT		 GPIO_Pin_5
#define CLIFF_FORWARD  GPIO_Pin_4
#define CLIFF_LEFT 		 GPIO_Pin_3
#define IRM_FORWARD    GPIO_Pin_1
#define IRM_Port			 GPIOB
void irm_config(void);

#endif

