#include "stm32f10x.h"
#include "gpio.h"
//#include "pwm.h"
#include "stdio.h"
#include "driver.h"
#include "SysTick.h"
#include "24l01.h"

float rx_left_x,rx_left_y;
u8 rx_left_l1,rx_left_l2;
float rx_right_x,rx_right_y;
u8 rx_right_r1,rx_right_r2;


int main(void)
{
	u8 t;
	u8 tmp_buf[33];
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	
	SysTick_Init(72);
	motor_gpio_config();
//	PWM_PIN_Init();
  GPIO_PIN_Init( );	
	NRF24L01_Init();
	while(NRF24L01_Check())	
	{
		GPIO_SetBits(GPIOC,GPIO_Pin_13);
		delay_ms(1000);
		GPIO_ResetBits(GPIOC,GPIO_Pin_13);
		delay_ms(1000);
	
	}
	GPIO_ResetBits(GPIOC,GPIO_Pin_13);
	delay_ms(1000);
	GPIO_SetBits(GPIOC,GPIO_Pin_13);
  NRF24L01_RX_Mode();	
	stop();	
	
	while(1)
	{
    if(NRF24L01_RxPacket(tmp_buf)==0)
    		{
    				tmp_buf[32]=0;
    			for(t=0;t<32;t++)
    			{
    				if(tmp_buf[t]=='l'&&tmp_buf[t+1]=='x'&&tmp_buf[t+2]==':')
    				{
    						rx_left_x=(float)(tmp_buf[t+3]-0x30)+(float)(tmp_buf[t+4]-0x30)/10+(float)(tmp_buf[t+5]-0x30)/100+(float)(tmp_buf[t+6]-0x30)/1000;
    		        rx_left_y=(float)(tmp_buf[t+7]-0x30)+(float)(tmp_buf[t+8]-0x30)/10+(float)(tmp_buf[t+9]-0x30)/100+(float)(tmp_buf[t+10]-0x30)/1000;
    					  rx_left_l1=tmp_buf[t+12]-0x30;
    						rx_left_l2=tmp_buf[t+15]-0x30;
    
    				}
    				if(tmp_buf[t]=='r'&&tmp_buf[t+1]=='x'&&tmp_buf[t+2]==':')
    				{
    						rx_right_x=(float)(tmp_buf[t+3]-0x30)+(float)(tmp_buf[t+4]-0x30)/10+(float)(tmp_buf[t+5]-0x30)/100+(float)(tmp_buf[t+6]-0x30)/1000;
    		        rx_right_y=(float)(tmp_buf[t+7]-0x30)+(float)(tmp_buf[t+8]-0x30)/10+(float)(tmp_buf[t+9]-0x30)/100+(float)(tmp_buf[t+10]-0x30)/1000;
    					  rx_right_r1=tmp_buf[t+12]-0x30;
    						rx_right_r2=tmp_buf[t+15]-0x30;
    						break;
    				}
    			  
    				
    			}
    		
    				
    		}else delay_us(100);
    		
    		
    		if(rx_left_y<0.8)
    		{
    			  forwards();
    						
    		}
    		else if(rx_left_y>2.5)
    		{
    			 backwards();
    						
    		}
    		
    		else if(rx_right_x>2.5)
    		{
    			 turn_left();
    		}
    		else  if(rx_right_x<0.8)
    		{
    			 turn_right();
    			
    		}
				else
				{
					stop();			
				}
    	}
}




