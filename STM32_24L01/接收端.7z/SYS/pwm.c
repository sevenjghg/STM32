/***************************************
***********PWM��ʼ����ʽ***************
***************************************/


#include "pwm.h"
#include "stm32f10x.h"




void PWM_PIN_Init(void)
{
		//??????//
	GPIO_InitTypeDef GPIO_InitStructure;            //??GPIO
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure; //?????
	TIM_OCInitTypeDef  TIM_OCInitStructure;         //??PWM??
	
	//**????**//
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4|RCC_APB1Periph_TIM3, ENABLE);	//???TIM4????
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO|RCC_APB2Periph_GPIOB, ENABLE);	 //GPIOB????
	
	//**GPIOB_Pin6???**//
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;				 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; 		 //??????
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO????50MHz
	GPIO_Init(GPIOB, &GPIO_InitStructure);					 
//	GPIO_SetBits(GPIOB,GPIO_Pin_6);
	
	 //GPIO????	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  //?????? ??????
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;               //??????
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;            //??????
	GPIO_Init(GPIOA,&GPIO_InitStructure);                  //?????
 //	GPIO_SetBits(GPIOA,GPIO_Pin_8);

  //TIM4???
	TIM_TimeBaseStructure.TIM_Period = 899; //????????????????????????????
	TIM_TimeBaseStructure.TIM_Prescaler = 0; //??????TIMx???????? 
	TIM_TimeBaseStructure.TIM_ClockDivision = 0; //??????:TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //TIM????
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); 
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

	//???TIM4 channel1 PWM	?? 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //?????????????
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //??????
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //???? TIM???????
	TIM_OC1Init(TIM3, &TIM_OCInitStructure);  
 	TIM_OC1Init(TIM4, &TIM_OCInitStructure);




	TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable);  //??TIM4_CH1
	TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);  //??TIM4_CH1

	//ռ�ձ�

	TIM_SetCompare1(TIM3,400);
	TIM_SetCompare1(TIM4,400);	

	TIM_CtrlPWMOutputs(TIM1,ENABLE);
    
  //TIMʹ�� 
	TIM_Cmd(TIM3, ENABLE);
	TIM_Cmd(TIM4, ENABLE);

}



