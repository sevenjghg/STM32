



#ifndef __GPIO_H_
#define __GPIO_H_
#include "stm32f10x.h"

void GPIO_PIN_Init(void);
void P1_1_High(void);
void P1_1_Low(void);
void P1_2_High(void);
void P1_2_Low(void);
void P2_1_High(void);
void P2_1_Low(void);
void P2_2_High(void);
void P2_2_Low(void);
void P3_1_High(void);
void P3_1_Low(void);
void P3_2_High(void);
void P3_2_Low(void);
void P4_1_High(void);
void P4_1_Low(void);
void P4_2_High(void);
void P4_2_Low(void);



#endif

