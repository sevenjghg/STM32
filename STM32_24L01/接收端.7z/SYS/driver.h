#ifndef __DRIVER_H_
#define __DRIVER_H_
#include "stm32f10x.h"

#define IN1 GPIO_Pin_3
#define IN2 GPIO_Pin_4
#define IN3 GPIO_Pin_5
#define IN4 GPIO_Pin_6



void motor_gpio_config(void);
void stop(void);
void forwards(void);
void backwards(void);
void turn_left(void);
void turn_right(void);

#endif
