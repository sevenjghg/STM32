#include "driver.h"



 void motor_gpio_config(void)
 {
	//���x�Y���w׃��
	 GPIO_InitTypeDef GPIO_InitStructure;
	//RCC�r�
	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOC, ENABLE);
	//GPIO��ʼ��	 
	 GPIO_InitStructure.GPIO_Pin = IN1| IN2| IN3| IN4;
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	 GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
	 GPIO_Init(GPIOA, &GPIO_InitStructure);
	 
	 
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	 GPIO_Init( GPIOC, &GPIO_InitStructure);

 }

	void stop(void)
	{
		GPIO_ResetBits(GPIOA,IN1);
		GPIO_ResetBits(GPIOA,IN2);
		GPIO_ResetBits(GPIOA,IN3);
		GPIO_ResetBits(GPIOA,IN4);	
	}
	
	void forwards(void)
	{
		GPIO_SetBits(GPIOA,IN1);
		GPIO_ResetBits(GPIOA,IN2);
		GPIO_SetBits(GPIOA,IN3);
		GPIO_ResetBits(GPIOA,IN4);		
		
	}
	
		void backwards(void)
	{
		GPIO_SetBits(GPIOA,IN2);
		GPIO_ResetBits(GPIOA,IN1);
		GPIO_SetBits(GPIOA,IN4);
		GPIO_ResetBits(GPIOA,IN3);		
		
	}
	
		void turn_left(void)
	{
		GPIO_SetBits(GPIOA,IN1);
		GPIO_ResetBits(GPIOA,IN2);	
		GPIO_SetBits(GPIOA,IN4);
		GPIO_ResetBits(GPIOA,IN3);		
	}
	
		void turn_right(void)
	{
		GPIO_SetBits(GPIOA,IN2);
		GPIO_ResetBits(GPIOA,IN1);	
		GPIO_SetBits(GPIOA,IN3);
		GPIO_ResetBits(GPIOA,IN4);			
	}


	