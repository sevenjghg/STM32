#ifndef __USART2_H
#define __USART2_H
#include "stm32f10x.h"
//#include "stdio.h"

extern int usart2_flag;
void USART2_Init(void);
void USART_SendByte(USART_TypeDef* USARTx, uint16_t Data);
void USART_SendString(USART_TypeDef * USARTx, char *str);
uint8_t USART_ReceiveByte(USART_TypeDef* USARTx);
#endif
