
#include "usart2.h"  //������Ҫ��ͷ�ļ�
#include "stdio.h"

//int usart2_flog;


void USART2_Init(void)
{
	//����ṹ��
	GPIO_InitTypeDef GPIO_InitStruct;
	USART_InitTypeDef USART_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;
		
	//RCCʱ��ʹ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2 , ENABLE);
	
	//GPIOA_PIN_2��ʼ������	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStruct.GPIO_Speed = 	GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	//GPIOA_PIN_3��ʼ������	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_3;
	//	GPIO_InitStruct.GPIO_Speed = 	GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	//USART��ʼ������
	USART_InitStruct.USART_Mode = USART_Mode_Tx|USART_Mode_Rx  ;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None ;
	USART_InitStruct.USART_Parity = USART_Parity_No;
	USART_InitStruct.USART_BaudRate = 9600;
	USART_InitStruct.USART_StopBits = 	USART_StopBits_1 ;
	USART_Init( USART2, &USART_InitStruct);
	
	//NVIC�ж�����
	NVIC_InitStruct.NVIC_IRQChannel =   USART2_IRQn  ;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStruct);
	
	
	USART_Cmd(USART2, ENABLE);
	USART_ITConfig( USART2, USART_IT_RXNE, ENABLE);
	
	
	
}

void USART_SendByte(USART_TypeDef* USARTx, uint16_t Data)
{
  /* Check the parameters */
  assert_param(IS_USART_ALL_PERIPH(USARTx));
  assert_param(IS_USART_DATA(Data)); 
    
  /* Transmit Data */
  USARTx->DR = (Data & (uint16_t)0x01FF);
  while (USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET);

}

void USART_SendString( USART_TypeDef * USARTx, char *str)
{
     while(*str!='\0')
     {
         USART_SendByte( USARTx, *str++ );	
     }
     while(USART_GetFlagStatus(USARTx,USART_FLAG_TC)==RESET);
}

uint8_t USART_ReceiveByte(USART_TypeDef* USARTx)
{
  while(USART_GetFlagStatus(USARTx,USART_FLAG_RXNE)==RESET);
  
  return (uint8_t)USART_ReceiveData(USART2);

}

//�жϺ���
void USART2_IRQHandler()
{
	uint32_t t;
//	while(USART_GetITStatus(USART1,USART_IT_RXNE) == RESET);
	if(USART_GetITStatus(USART2,USART_IT_RXNE) != RESET)
	{
//		t = USART_ReceiveByte(USART2);
//		switch(t)
//		{
//			case '0': usart2_flag = 0;break;
//			case '1': usart2_flag = 1;break;
//			case '2': usart2_flag = 2;break;
//			case '3': usart2_flag = 3;break;
//			case '4': usart2_flag = 4;break;
//			case '5': usart2_flag = 5;break;
//			default: usart2_flag = 0;
//		}
//	
//	}
//		USART_SendByte(USART2,t);

}
#pragma import(__use_no_semihosting)             
                 
struct __FILE 
{ 
	int handle; 

}; 

FILE __stdout;          
_sys_exit(int x) 
{ 
	x = x; 
} 

int fputc(int ch, FILE *f)
{
		
		USART_SendData(USART2, (uint8_t) ch);			
		while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);			
		return (ch);
}


int fgetc(FILE *f)
{		
		while (USART_GetFlagStatus(USART2, USART_FLAG_RXNE) == RESET);
		return (int)USART_ReceiveData(USART2);
}

