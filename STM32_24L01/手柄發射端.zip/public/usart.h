#ifndef _USART_H
#define _USART_H

#include"system.h"
#include"stdio.h"
#include"led.h"
#include"oled.h"

//void USART2_Init();
void USART_SendByte(USART_TypeDef* USARTx, uint16_t Data);
void USART_SendString( USART_TypeDef * USARTx, char *str);
uint8_t USART_ReceiveByte(USART_TypeDef* USARTx);
void USART_SendFloat(USART_TypeDef* USARTx,float d);

#endif
