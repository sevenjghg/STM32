#ifndef _WKUP_H
#define _WKUP_H

#include"system.h"


void Enter_Standby_Mode(void);


#endif
