#ifndef __TIMER_H_
#define __TIMER_H_

#include "system.h"

extern __IO u8 system_timer_1ms_flag;
extern __IO u8 system_timer_5ms_flag;
extern __IO u8 system_timer_5ms_cnt;
extern __IO u8 system_timer_10ms_flag;
extern __IO u8 system_timer_10ms_cnt;
extern __IO u8 timer3_flag;


void timer_1ms(void);
void Timer_SRD_Init(u16 arr,u16 psc);






#endif

