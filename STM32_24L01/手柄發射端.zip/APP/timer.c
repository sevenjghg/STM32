#include "timer.h"

__IO u8 system_timer_1ms_flag=0;

__IO u8 system_timer_5ms_flag=0;
__IO u8 system_timer_5ms_cnt=0;

__IO u8 system_timer_10ms_flag=0;
__IO u8 system_timer_10ms_cnt=0;

__IO u8 timer3_flag=0;

void timer_1ms(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	
	TIM_TimeBaseInitStruct.TIM_ClockDivision = 0;
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStruct.TIM_Period = 1000-1;
	TIM_TimeBaseInitStruct.TIM_Prescaler = 72-1; 
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStruct);

	TIM_Cmd(TIM4,ENABLE);
	TIM_ITConfig(TIM4,TIM_IT_Update, ENABLE);
	TIM_ClearFlag(TIM4, TIM_IT_Update);
	
	NVIC_InitStruct.NVIC_IRQChannel = TIM4_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStruct);
	
}

void Timer_SRD_Init(u16 arr,u16 psc)
{
	TIM_TimeBaseInitTypeDef    TIM_TimeBaseInitSture;
	NVIC_InitTypeDef           NVIC_InitSture;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);//ʹ��TIM3
	
	//��ʼ����ʱ��
	TIM_TimeBaseInitSture.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInitSture.TIM_Period=arr;
	TIM_TimeBaseInitSture.TIM_Prescaler=psc;
	TIM_TimeBaseInitSture.TIM_ClockDivision=0;
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitSture);
	
	//���������жϣ�������ʽ�ж�
	TIM_ClearFlag(TIM3, TIM_FLAG_Update);
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);
//	TIM_ITConfig(TIM3,TIM_IT_Trigger,ENABLE);
	
	//�ж����ȼ�����
	NVIC_InitSture.NVIC_IRQChannel=TIM3_IRQn;
	NVIC_InitSture.NVIC_IRQChannelCmd=ENABLE;
	NVIC_InitSture.NVIC_IRQChannelPreemptionPriority=0;
	NVIC_InitSture.NVIC_IRQChannelSubPriority=3;
	NVIC_Init(&NVIC_InitSture);
	
//	TIM_Cmd(TIM3,ENABLE);
}

void TIM3_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)!=RESET)
	{
		timer3_flag++;
	//	printf("Enter timer3 IRQHandler\r\n");
	//	printf(" timer3_flag:%d \r\n",timer3_flag);
		TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
		
	}
}


void TIM4_IRQHandler (void)
{
	if(TIM_GetITStatus(TIM4,TIM_IT_Update)==SET)
	{
			TIM_ClearFlag(TIM4, TIM_IT_Update);
			
			system_timer_1ms_flag=1;
		  system_timer_5ms_cnt++;
			system_timer_10ms_cnt++;
			
			if(system_timer_5ms_cnt >= 5)
			{
				system_timer_5ms_cnt = 0;
				system_timer_5ms_flag = 1;  // 5ms���r��־λ
				//Wave_SRD_Strat();	
			}
			
			if(system_timer_10ms_cnt >= 10)
			{
				system_timer_10ms_cnt = 0;
				system_timer_10ms_flag = 1;  // 10ms���r��־λ
			}
		
		
	}

}



