#ifndef _DAC_H
#define _DAC_H

#include"system.h"

void DAC1_Init(void);

#endif
