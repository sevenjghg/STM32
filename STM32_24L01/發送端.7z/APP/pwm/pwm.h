#ifndef _PWM_H
#define _PWM_H 

#include"system.h"

void TIM3_PWM_CH1_Init(u16 pre,u16 psc);


#endif
