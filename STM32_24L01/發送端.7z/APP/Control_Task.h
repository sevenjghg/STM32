#ifndef _CONTROL_TASK_H_
#define _CONTROL_TASK_H_
#include "system.h"
void Control_task(void);
extern int32_t adcx;
#endif
