#ifndef _WWDG_H
#define _WWDG_H

#include"system.h"

#include"led.h"

void WWDG_Init(void);


#endif
